{
    'name': 'enfermeria',
    'description': 'Registro de una enfermeria',
    'author': 'Ivan',
    'application': True,
    'data': ['./views/enfermeros.xml', './views/operaciones.xml', './views/pacientes.xml']
}
from odoo import models, fields, api 

class operaciones(models.Model):
    _name = 'enfermeria.operaciones'
    identificador = fields.Integer('Identificador', required = True)
    especialidad = fields.Char('Especialidad', required = True)
from odoo import models, fields, api 

class enfermeros(models.Model):
    _name = 'enfermeria.enfermeros'
    identificador = fields.Integer('Identificador', required = True)
    especialidad = fields.Char('Especialidad', required = True)
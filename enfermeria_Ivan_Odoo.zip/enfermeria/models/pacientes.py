from odoo import models, fields, api 

class pacientes(models.Model):
    _name = 'enfermeria.pacientes'
    identificador = fields.Integer('Identificador', required = True)
    especialidad = fields.Char('Especialidad', required = True)